﻿using lab3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        Catalog catalog2 = new Favourite("Каталог кинофильмов 2022", 2022);
        Catalog catalog3 = new Blocked("Каталог заблокированных фильмов 2022", 2022);

        Film film1 = new Film();
        Film film2 = new Film("Название фильма", 2022, "Жанр", "Описание");
        Film film3 = new Film(film2);
        List<Film> films = new List<Film>();

        string title = null;
        int year = 0;

        while (true)
        {
            Console.WriteLine("\n1.  Добавить фильм ");
            Console.WriteLine("2.  Добавить фильм в избранное");
            Console.WriteLine("3.  Добавить фильм в заблокированное");
            Console.WriteLine("4.  Удалить фильм");
            Console.WriteLine("5.  Редактировать фильм");
            Console.WriteLine("6.  Просмотр каталога");
            Console.WriteLine("7.  Демонстрация атрибутов всех элементов");
            Console.WriteLine("8.  Тестирование добавления элемента в список");
            Console.WriteLine("9.  Просмотр избранных фильмов");
            Console.WriteLine("10.  Просмотр заблокированных фильмов");
            Console.WriteLine("11. Добавление элемента в список");
            Console.WriteLine("0. Выход");

            Console.Write("Сделайте свой выбор: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.Write("Введите название фильма: ");
                    title = Console.ReadLine();
                    Console.Write("Введите год фильма: ");
                    year = int.Parse(Console.ReadLine());
                    Console.Write("Введите жанр фильма: ");
                    string genre = Console.ReadLine();
                    Console.Write("Введите описание фильма: ");
                    string description = Console.ReadLine();

                    Film newFilm = new Film(title, year, genre, description);
                    catalog2.AddFilm(newFilm);
                    break;
                case "2":
                    Console.Write("Введите название фильма, который нужно добавить в избранное: ");
                    string titleToAdd = Console.ReadLine();
                    Film filmToAdd = catalog2.GetFilmByTitle(titleToAdd);
                    if (filmToAdd != null)
                    {
                        catalog2.AddFilm(filmToAdd);
                    }
                    else
                    {
                        Console.WriteLine($"Фильм с названием '{titleToAdd}' не найден в каталоге.");
                    }
                    break;
                case "3":
                    Console.Write("Введите название фильма, который нужно добавить в заблокированное: ");
                    string titleToAddBlocked = Console.ReadLine();
                    Film filmToAddBlocked = catalog2.GetFilmByTitle(titleToAddBlocked);
                    if (filmToAddBlocked != null)
                    {
                        catalog3.AddFilm(filmToAddBlocked);
                    }
                    else
                    {
                        Console.WriteLine($"Фильм с названием '{titleToAddBlocked}' не найден в каталоге.");
                    }
                    break;
                case "4":
                    Console.Write("Введите название фильма, который нужно удалить: ");
                    string titleToRemove = Console.ReadLine();
                    catalog2.RemoveFilm(titleToRemove);
                    break;
                case "5":
                    Console.Write("Введите название фильма, который нужно отредактировать: ");
                    string titleToEdit = Console.ReadLine();
                    catalog2.EditFilm(titleToEdit);
                    break;
                case "6":
                    catalog2.ViewCatalog();
                    break;
                case "7":
                    catalog2.DisplayAttributesForAllItems();
                    break;
                case "8":
                    Catalog newCatalog = new Favourite("название", 2022); 
                    catalog2.AddItem(newCatalog);
                    Console.WriteLine("Фильм успешно добавлен в список.");
                    break;
                case "9":
                    Console.WriteLine("\nИзбранные фильмы:");
                    catalog2.ViewCatalog();
                    break;
                case "10":
                    Console.WriteLine("\nЗаблокированные фильмы:");
                    catalog3.ViewCatalog();
                    break;
                case "11":
                    Console.Write("Введите название каталога для добавления в список: ");
                    string catalogName = Console.ReadLine();
                    Console.Write("Введите год каталога: ");
                    int catalogYear;
                   
                    while (!int.TryParse(Console.ReadLine(), out catalogYear))
                    {
                        Console.WriteLine("Некорректный ввод. Пожалуйста, введите целое число для года.");
                    }
                    Catalog newCatalogItem = new Favourite(catalogName, catalogYear); 
                    catalog2.AddItem(newCatalogItem);
                    Console.WriteLine($"Каталог '{catalogName}' успешно добавлен в список.");
                    break;
                case "0":
                    Console.WriteLine("Выход из программы");
                    Environment.Exit(0);
                    break;
                default:
                    GC.Collect();
                    Console.WriteLine("Неверный выбор. Пожалуйста, попробуйте снова.");
                    break;
            }
        }
    }
}
