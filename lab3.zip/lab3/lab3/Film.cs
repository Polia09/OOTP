﻿using System;
using System.Collections.Generic;
namespace lab3
{
    class Film : IDisposable
    {
        private string title;
        private int year;
        private string genre;
        private string description;
        private List<Film> copies = new List<Film>();
        private bool disposed = false;


        public Film()
        {
            Console.WriteLine("Вызван конструктор Film()");
        }

        public Film(string title, int year, string genre, string description)
        {
            Console.WriteLine($"Вызван конструктор Film({title}, {year}, {genre}, {description})");
            this.title = title;
            this.year = year;
            this.genre = genre;
            this.description = description;
        }

        public Film(Film other)
            : this(other.title, other.year, other.genre, other.description)
        {
            Console.WriteLine($"Вызван конструктор копирования Film({other.title}, {other.year}, {other.genre}, {other.description})");
        }

        public void CreateCopies(int count)
        {
            for (int i = 0; i < count; i++)
            {
                Film copiedFilm = new Film(this);
                copies.Add(copiedFilm);
            }
        }
        public void ViewCopies()
        {
            Console.WriteLine($"Название фильма: {title}");
            Console.WriteLine($"Количество копий: {copies.Count}");
            foreach (var copy in copies)
            {
                Console.WriteLine($"Копия: {copy.title}");
            }
        }


        public string Title => title;
        public int Year => year;
        public string Genre => genre;
        public string Description => description;

        public void EditFilm(string newTitle, int newYear, string newGenre, string newDescription)
        {
            title = newTitle;
            year = newYear;
            genre = newGenre;
            description = newDescription;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    Console.WriteLine("Вызван метод Dispose() для Film");
                }

                disposed = true;
            }
        }

        ~Film()
        {
            Dispose(false);
            Console.WriteLine("Вызван деструктор Film()");
        }
    }
   

}

