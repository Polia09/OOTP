﻿using System;
using System.Collections.Generic;
namespace lab3
{
    class Film : IDisposable
    {
        private string title;
        private int year;
        private string genre;
        private string description;
        private List<Film> copies = new List<Film>();
        private bool disposed = false;
        protected Film[] internalArray;
        private int currentIndex = 0;
        private int[] array = new int[10];


        public Film()
        {
            Console.WriteLine("Вызван конструктор Film()");
        }

        public Film(string title, int year, string genre, string description)
        {
            Console.WriteLine($"Вызван конструктор Film({title}, {year}, {genre}, {description})");
            this.title = title;
            this.year = year;
            this.genre = genre;
            this.description = description;
        }

        public Film(Film other)
            : this(other.title, other.year, other.genre, other.description)
        {
            Console.WriteLine($"Вызван конструктор копирования Film({other.title}, {other.year}, {other.genre}, {other.description})");
        }
        public Film(int size)
        {
            internalArray = new Film[size];
        }

        public static Film operator +(Film film, Film itemToAdd)
        {
            if (film.internalArray != null && itemToAdd != null)
            {
                for (int i = 0; i < film.internalArray.Length - 1; i++)
                {
                    if (film.internalArray[i] == null)
                    {
                        film.internalArray[i] = itemToAdd;
                        Console.WriteLine($"Объект добавлен во внутренний массив на позицию {i}");
                        break;

                    }
                }

            }
            return film;
        }
        public static Film operator ++(Film film)
        {
            int value = 0;
            if(film.currentIndex < film.array.Length)
            {
                film.array[film.currentIndex++] = value;
                film.currentIndex++;
            }
            return film;
        }
        
        public void DisplayArray()
        {
            Console.WriteLine("Содержимое массива: ");
            for(int i = 0; i<currentIndex; i++)
            {
                Console.WriteLine($"array[{i}] = {array [i]}");
            }
        }
        public Film this[int index]
        {
            get
            {
                if(index < 0 || index >= copies.Count)
                {
                    throw new IndexOutOfRangeException("Индекс вышел за пределы");
                }
                return copies[index];
            }
        }
        public static Film operator <<(Film film, int shift)
        {
            Console.WriteLine(
                "Название: " + film.Title +
                "\nГод: " + film.Year +
                "\nЖанр: " + film.Genre +
                "\nОписание: " + film.Description + "\n");
            return film;

        }
        public string Show_Name()
        {
            return this.title;
        }
        public string Show_Description()
        {
            return this.description;
        }
       
        
        public void CreateCopies(int count)
        {
            for (int i = 0; i < count; i++)
            {
                Film copiedFilm = new Film(this);
                copies.Add(copiedFilm);
            }
        }
        public void ViewCopies()
        {
            Console.WriteLine($"Название фильма: {title}");
            Console.WriteLine($"Количество копий: {copies.Count}");
            foreach (var copy in copies)
            {
                Console.WriteLine($"Копия: {copy.title}");
            }
        }


        public string Title => title;
        public int Year => year;
        public string Genre => genre;
        public string Description => description;

        public void EditFilm(string newTitle, int newYear, string newGenre, string newDescription)
        {
            title = newTitle;
            year = newYear;
            genre = newGenre;
            description = newDescription;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    Console.WriteLine("Вызван метод Dispose() для Film");
                }

                disposed = true;
            }
        }
        
        ~Film()
        {
            Dispose(false);
            Console.WriteLine("Вызван деструктор Film()");
        }
    }
   

}

