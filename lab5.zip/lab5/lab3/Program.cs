﻿using lab3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static List<Film> films = new List<Film>();
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        Catalog catalog2 = new Favourite("", 0);
        Catalog catalog3 = new Blocked("", 0);

        //Film film1 = new Film();
        //Film film2 = new Film("Название фильма", 2022, "Жанр", "Описание");
        //Film film3 = new Film(film2);
        //List<Film> films = new List<Film>();

        //Catalog favCatalog = new Favourite("Название", 2024); 
        //Catalog blockedCatalog = new Blocked("Название", 2024);
        Favourite catalog4 = new Favourite("Название", 2024);
        Film films1 = null;

        string title = null;
        int year = 0;

        while (true)
        {
            Console.WriteLine("\n1.  Добавить фильм ");
            Console.WriteLine("2.  Добавить фильм в избранное");
            Console.WriteLine("3.  Добавить фильм в заблокированное");
            Console.WriteLine("4.  Удалить фильм");
            Console.WriteLine("5.  Редактировать фильм");
            Console.WriteLine("6.  Просмотр каталога");
            Console.WriteLine("7.  Демонстрация атрибутов всех элементов");
            Console.WriteLine("8.  Тестирование добавления элемента в список");
            Console.WriteLine("9.  Просмотр избранных фильмов");
            Console.WriteLine("10.  Просмотр заблокированных фильмов");
            Console.WriteLine("11. Добавление элемента в список");
            Console.WriteLine("12. Оператор +");
            Console.WriteLine("13. Оператор ++");
            Console.WriteLine("14. Оператор [] ");
            Console.WriteLine("15. Оператор <<");
            Console.WriteLine("16. Операторы сравнения в Favourite");
            Console.WriteLine("17. Операторы сравнения в Blocked");
            Console.WriteLine("18. Операторы == и =!");
            Console.WriteLine("0. Выход");

            Console.Write("Сделайте свой выбор: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.Write("Введите название фильма: ");
                    title = Console.ReadLine();
                    Console.Write("Введите год фильма: ");
                    year = int.Parse(Console.ReadLine());
                    Console.Write("Введите жанр фильма: ");
                    string genre = Console.ReadLine();
                    Console.Write("Введите описание фильма: ");
                    string description = Console.ReadLine();

                    Film newFilm = new Film(title, year, genre, description);
                    catalog2.AddFilm(newFilm);
                    films.Add(newFilm);
                    break;
                case "2":
                    Console.Write("Введите название фильма, который нужно добавить в избранное: ");
                    string titleToAdd = Console.ReadLine();
                    Film filmToAdd = catalog4.GetFilmByTitle(titleToAdd);
                    if (filmToAdd != null)
                    {
                        // Убедитесь, что catalog2 является объектом типа Favourite
                        if (catalog4 is Favourite)
                        {
                            // Преобразуйте catalog2 к типу Favourite и вызовите метод AddFilm
                            ((Favourite)catalog4).AddFilm(filmToAdd);
                        }
                        else
                        {
                            Console.WriteLine("Объект catalog4 не является объектом типа Favourite.");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Фильм с названием '{titleToAdd}' не найден в каталоге.");
                    }
                    break;
                case "3":
                    Console.Write("Введите название фильма, который нужно добавить в заблокированное: ");
                    string titleToAddBlocked = Console.ReadLine();
                    Film filmToAddBlocked = catalog2.GetFilmByTitle(titleToAddBlocked);
                    if (filmToAddBlocked != null)
                    {
                        catalog3.AddFilm(filmToAddBlocked);
                    }
                    else
                    {
                        Console.WriteLine($"Фильм с названием '{titleToAddBlocked}' не найден в каталоге.");
                    }
                    break;
                case "4":
                    Console.Write("Введите название фильма, который нужно удалить: ");
                    string titleToRemove = Console.ReadLine();
                    catalog2.RemoveFilm(titleToRemove);
                    break;
                case "5":
                    Console.Write("Введите название фильма, который нужно отредактировать: ");
                    string titleToEdit = Console.ReadLine();
                    catalog2.EditFilm(titleToEdit);
                    break;
                case "6":
                    catalog2.ViewCatalog();
                    break;
                case "7":
                    catalog2.DisplayAttributesForAllItems();
                    break;
                case "8":
                    Catalog newCatalog = new Favourite("название", 2022);
                    catalog2.AddItem(newCatalog);
                    Console.WriteLine("Фильм успешно добавлен в список.");
                    break;
                case "9":
                    Console.WriteLine("\nИзбранные фильмы:");
                    catalog2.ViewCatalog();
                    break;
                case "10":
                    Console.WriteLine("\nЗаблокированные фильмы:");
                    catalog3.ViewCatalog();
                    break;
                case "11":
                    Console.Write("Введите название каталога для добавления в список: ");
                    string catalogName = Console.ReadLine();
                    Console.Write("Введите год каталога: ");
                    int catalogYear;

                    while (!int.TryParse(Console.ReadLine(), out catalogYear))
                    {
                        Console.WriteLine("Некорректный ввод. Пожалуйста, введите целое число для года.");
                    }
                    Catalog newCatalogItem = new Favourite(catalogName, catalogYear);
                    catalog2.AddItem(newCatalogItem);
                    Console.WriteLine($"Каталог '{catalogName}' успешно добавлен в список.");
                    break;

                case "12":
                    Console.WriteLine("Добавление фильма во внутренний массив.");
                    films1 = new Film("Фильм 1", 2022, "Жанр 1", "Описание 1");
                    Film films2 = new Film("Фильм 2", 2023, "Жанр 2", "Описание 2");
                    films1 += films2;
                    break;
                case "13":
                    Console.WriteLine("Добавление элемента во внутренний массив.");
                    films1++;
                    films1.DisplayArray();
                    break;
                case "14":
                    {
                        Console.WriteLine("Введите индекс элемента, который хотите изменить:");
                        int index = int.Parse(Console.ReadLine());

                        Console.WriteLine("Введите новое название фильма:");
                        string newTitle = Console.ReadLine();

                        Console.WriteLine("Введите новый год выпуска фильма:");
                        int newYear = int.Parse(Console.ReadLine());

                        Console.WriteLine("Введите новый жанр фильма:");
                        string newGenre = Console.ReadLine();

                        Console.WriteLine("Введите новое описание фильма:");
                        string newDescription = Console.ReadLine();

                        if (index >= 0 && index < films.Count)
                        {
                            films[index].EditFilm(newTitle, newYear, newGenre, newDescription);
                            Console.WriteLine("Фильм успешно обновлен.");
                        }
                        else
                        {
                            Console.WriteLine("Индекс вне допустимого диапазона.");
                        }
                        break;
                    }
                case "15":
                    {
                        Console.WriteLine("Выберите индекс фильма:");
                        int index = int.Parse(Console.ReadLine());

                        try
                        {
                            Film selectedFilm = films[index];
                            Console.WriteLine("Информация о выбранном фильме:");
                            Console.WriteLine("Название: " + selectedFilm.Show_Name());
                            Console.WriteLine("Год: " + selectedFilm.Year);
                            Console.WriteLine("Жанр: " + selectedFilm.Genre);
                            Console.WriteLine("Описание: " + selectedFilm.Show_Description());
                        }
                        catch (IndexOutOfRangeException)
                        {
                            Console.WriteLine("Ошибка: Некорректный индекс фильма.");
                        }

                        break;
                    }
                case "16":
                    Console.WriteLine("Введите название первого фильма:");
                    string title1 = Console.ReadLine();

                    Console.WriteLine("Введите год выпуска первого фильма:");
                    int year1;
                    while (!int.TryParse(Console.ReadLine(), out year1))
                    {
                        Console.WriteLine("Некорректный ввод. Введите целое число для года выпуска фильма:");
                    }

                    Console.WriteLine("Введите название второго фильма:");
                    string title2 = Console.ReadLine();

                    Console.WriteLine("Введите год выпуска второго фильма:");
                    int year2;
                    while (!int.TryParse(Console.ReadLine(), out year2))
                    {
                        Console.WriteLine("Некорректный ввод. Введите целое число для года выпуска фильма:");
                    }

                    Favourite favourite1 = new Favourite(title1, year1);
                    Favourite favourite2 = new Favourite(title2, year2);

                    Console.WriteLine($"Сравнение избранных: {favourite1.Show_Name()} {(favourite1 > favourite2 ? ">" : "<")} {favourite2.Show_Name()}");
                    break;

                case "17":
                    Console.WriteLine("Введите название первого заблокированного фильма:");
                    string name3 = Console.ReadLine();

                    Console.WriteLine("Введите год выпуска первого заблокированного фильма:");
                    int year3;
                    while (!int.TryParse(Console.ReadLine(), out year3))
                    {
                        Console.WriteLine("Некорректный ввод. Введите целое число для года выпуска фильма:");
                    }

                    Console.WriteLine("Введите название второго заблокированного фильма:");
                    string name4 = Console.ReadLine();

                    Console.WriteLine("Введите год выпуска второго заблокированного фильма:");
                    int year4;
                    while (!int.TryParse(Console.ReadLine(), out year4))
                    {
                        Console.WriteLine("Некорректный ввод. Введите целое число для года выпуска фильма:");
                    }

                    Blocked blocked1 = new Blocked(name3, year3);
                    Blocked blocked2 = new Blocked(name4, year4);

                    Console.WriteLine($"Сравнение заблокированных: {blocked1.Show_Name()} {(blocked1 > blocked2 ? ">" : "<")} {blocked2.Show_Name()}");
                    break;

                case "18":
                    Console.WriteLine("Введите название первого избранного фильма:");
                    string name5 = Console.ReadLine();

                    Console.WriteLine("Введите год выпуска первого избранного фильма:");
                    int year5;
                    while (!int.TryParse(Console.ReadLine(), out year5))
                    {
                        Console.WriteLine("Некорректный ввод. Введите целое число для года выпуска фильма:");
                    }

                    Console.WriteLine("Введите название второго избранного фильма:");
                    string name6 = Console.ReadLine();

                    Console.WriteLine("Введите год выпуска второго избранного фильма:");
                    int year6;
                    while (!int.TryParse(Console.ReadLine(), out year6))
                    {
                        Console.WriteLine("Некорректный ввод. Введите целое число для года выпуска фильма:");
                    }

                    Favourite favourite3 = new Favourite(name5, year5);
                    Favourite favourite4 = new Favourite(name6, year6);

                    Console.WriteLine($"Сравнение избранных: {favourite3.Show_Name()} {(favourite3 == favourite4 ? "==" : "!=")} {favourite4.Show_Name()}");
                    break;
                case "0":
                    Console.WriteLine("Выход из программы");
                    Environment.Exit(0);
                    break;
                default:
                    GC.Collect();
                    Console.WriteLine("Неверный выбор. Пожалуйста, попробуйте снова.");
                    break;
            }
        }
    }
}